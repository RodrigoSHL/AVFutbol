<!-- Bootstrap core JavaScript-->
    <script src="js/jquery.js" type="text/javascript"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <script src="js/jquery.gritter.js" type="text/javascript"></script>
	<script src="js/notificaciones.js" type="text/javascript"></script>

	<script src="js/login.js" type="text/javascript"></script>

